# -*- coding: UTF-8 -*-
import producer
import time
import random
import sys
def test_producer():
    p = producer.Producer(KafkaServerList=["10.10.149.20:6667"], ClientId="Procucer01", Topic="wuxiaopan")
    for i in range(10):
        time.sleep(1)
        closePrice = random.randint(1, 500)
        msg = {
            "Publisher": "Procucer01",
            "股票代码": 70000 + i,
            "昨日收盘价": closePrice,
            "今日开盘价": 0,
            "今日收盘价": 100,
        }
        p.sendMessage(value=msg)
    # p.sendNow()
    p.closeConnection()

if __name__ == "__main__":
    try:
        test_producer()
    finally:
        sys.exit()
