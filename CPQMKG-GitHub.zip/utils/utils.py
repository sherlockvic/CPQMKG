# coding: UTF-8
import os
import re
import time
import torch
import numpy as np
from tqdm import tqdm
from datetime import timedelta

def read_from_txt(path):
    texts = []
    text_labels = []
    with open(path, 'r', encoding='UTF-8') as f:
        # Text_labels after text and a tab is in between
        print('read from', path)
        for line in tqdm(f):
            lin = line.strip()
            try:
                t, l = lin.split('\t')
            except:
                print(lin)
                input()
            texts.append(t)
            text_labels.append(int(l))
    return texts, text_labels

def get_time_dif(start_time):
    end_time = time.time()
    time_dif = end_time - start_time
    return timedelta(seconds=int(round(time_dif)))
