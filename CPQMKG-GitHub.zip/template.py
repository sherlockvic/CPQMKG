import os
from langgraph.graph import END, StateGraph, START
from langchain_core.output_parsers import StrOutputParser
from pydantic import BaseModel, Field
from typing import List,Literal
from typing_extensions import TypedDict
from langchain_community.graphs import Neo4jGraph
from langchain_community.vectorstores.neo4j_vector import remove_lucene_chars
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate



os.environ["OPENAI_API_KEY"] = "**********"
os.environ["OPENAI_API_BASE"] = "*********"

os.environ["NEO4J_URI"] = "bolt://localhost:7687"
os.environ["NEO4J_USERNAME"] = "neo4j"
os.environ["NEO4J_PASSWORD"] = "XXXXXX"


class Graph_Entity(TypedDict):
    """
    Represents an entity within the graph.

    Attributes:
        name: The name of the entity.
        labels: A list of labels associated with the entity.
    """
    name: str
    labels: List[str]

class GraphState(TypedDict):
    """
    Represents the state of our graph.

    Attributes:
        question: A string representing the question posed.
        generation: A string representing the LLM generation.
        entities: A list of entities, where each entity is represented as a dictionary.
        documents: A list of documents related to the graph state.
    """
    question: str
    generation: str
    entities: List[Graph_Entity]  # Change here to use List[Entity]
    documents: List[str]


class Entities(BaseModel):
    """
    Identify and capture information about entities from text
    """

    names: List[str] = Field(
        description=
            "All the brand, product, parameter entities related to the field of radiator products that appear in the text",
    )


def generate_full_text_query(input_query: str) -> str:
    """
    Generate a full-text search query for a given input string.

    This function constructs a query string suitable for a full-text search.
    It processes the input string by splitting it into words and appending a
    similarity threshold (~2 changed characters) to each word, then combines
    them using the AND operator. Useful for mapping entities from user questions
    to database values, and allows for some misspellings.

    Args:
        input_query (str): The extracted entity name pulled from the users question

    Returns:
        str: _description_
    """
    full_text_query = ""

    # split out words and remove any special characters reserved for cipher query
    words = [el for el in remove_lucene_chars(input_query).split() if el]
    for word in words[:-1]:
        full_text_query += f" {word} AND"
    full_text_query += f" {words[-1]}"
    # print(full_text_query)
    return full_text_query.strip()

def retrieval_generate_router(state):
    """
    Route question to generate or pkg_ner.

    Args:
        state (dict): The current graph state

    Returns:
        str: Next node to call
    """
    # print("---ROUTE RETRIEVAL OR GENERATE---")
    entities = state["entities"]

    if entities:
        # print("---ROUTE QUESTION TO RETRIEVAL---")
        return "retrieval"
    else:
        # print("---ROUTE QUESTION TO GENERATE---")
        return "generate"

# NODES

def generate(state):
    """
    Retrieve documents

    Args:
        state (dict): The current graph state

    Returns:
        state (dict): New key added to state, documents, that contains retrieved documents
    """
    # print("---GENERATE---")
    question = state["question"]

    system_prompt = """You are Fengshen Zhiyu(风神智语), the AI sales assistant of Deepcool（九州风神）\n
                    Deepcool is a professional company integrating computer cooling product design, R&D, production and sales.
                    The company's products cover the overall computer cooling system.\n
                    You are responsible for the marketing of Deepcool products, so that buyers have a stronger desire to buy Deepcool products instead of other brands' products."""
    re_write_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", system_prompt),
            (
                "human",
                "{question}",
            ),
        ]
    )

    generation_chain = re_write_prompt | llm | StrOutputParser()
    generate_content = generation_chain.invoke(question)
    return {"generation": generate_content, "question": question}

def ner(state):

    # print("---NER---")
    question = state["question"]
    result = ''
    ner_prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "你是一个提取电子产品、散热器产品领域的命名实体识别专家",
            ),
            (
                "human",
                "从以下输入的文本中提取出有关电子产品、散热器产品相关的实体并将所有的实体以列表的形式输出，如果没有相关实体，则回复空列表。输入：{input_query}"
            )
        ]
    )

    entity_extract_chain = ner_prompt | llm.with_structured_output(Entities)
    entities = entity_extract_chain.invoke(question)
    print(entities)
    graph_entities = []
    for entity in entities.names:
        if not entity:
            continue

        response = graph.query(
            """CALL db.index.fulltext.queryNodes('productindex', $query, {limit: 1})
                YIELD node, score
                WITH node
                RETURN labels(node) AS labels, properties(node) AS properties
            """,
            {"query": entity},
        )
        for el in response:
            properties = el["properties"]
            labels = el["labels"]
            name = properties["name"]
            graph_entities.append({"name": name, "labels": labels})

    print(graph_entities)
    # print(result)
    # documents = [result]
    # documents = [Document(page_content=result)]

    return {"entities": graph_entities, "question": question}

def retrieval(state):

    # print("---NER---")
    question = state["question"]
    entities = state["entities"]
    new_entities = []
    result = ''

    for entity in entities:
        entity = entity["name"]
        print(entity)
        response = graph.query(
            """
            CALL db.index.fulltext.queryNodes('productindex', $query, {limit:1})
            YIELD node,score
            CALL {
            WITH node
            MATCH (node)-[r]->(neighbor)
            RETURN node.name + ' - ' + type(r) + ' -> ' + neighbor.name AS output
            UNION ALL
            WITH node
            MATCH (node)<-[r]-(neighbor)
            RETURN neighbor.name + ' - ' + type(r) + ' -> ' +  node.name AS output
            }
            RETURN output
            """,
            {"query": entity},
        )
        #  LIMIT 50
        result += "\n".join([el['output'] for el in response])
        print(result)
    # print(result)
    documents = [result]
    # documents = [Document(page_content=result)]

    return {"entities": new_entities, "question": question, "documents": documents}

def retrieval_generate(state):
    """
        Retrieve documents

        Args:
            state (dict): The current graph state

        Returns:
            state (dict): New key added to state, documents, that contains retrieved documents
        """
    # print("---RETRIEVAL GENERATE---")
    question = state["question"]
    documents = state["documents"]


    system_prompt = """You are Fengshen Zhiyu(风神智语), the AI sales assistant of Deepcool（九州风神）.\n
                    You are good at answering users’ questions based on the context they provide.\n
                    You are responsible for the marketing of Deepcool products, so that buyers have a stronger desire to buy Deepcool products instead of other brands' products."""
    human_prompt = """
            Use the following pieces of retrieved context to answer the question. If you don't know the answer, just answer it by yourself without the context retrieved.
            Question: {question} 
            Context: {context} 
            Answer:
    """
    re_write_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", system_prompt),
            (
                "human",human_prompt
            ),
        ]
    )

    retrieval_generation_chain = re_write_prompt | llm | StrOutputParser()
    documents = '\n\n'.join(documents)
    generate_content = retrieval_generation_chain.invoke({"context": documents,"question": question})

    return {"generation": generate_content, "question": question}



# EDGES


# LLM with function call
llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)
graph = Neo4jGraph()

workflow = StateGraph(GraphState)

# Define the nodes
workflow.add_node("generate", generate)  # web search
workflow.add_node("ner", ner)  # web search
workflow.add_node("retrieval",retrieval)  # web search
workflow.add_node("retrieval_generate", retrieval_generate)  # web search


workflow.add_edge(START,"ner")
workflow.add_edge("retrieval","retrieval_generate")
workflow.add_edge("retrieval_generate", END)
workflow.add_edge("generate", END)

workflow.add_conditional_edges(
    "ner",
    retrieval_generate_router,
    {
        "retrieval": "retrieval",
        "generate": "generate",
    },
)



# Compile
app = workflow.compile()

# import matplotlib.pyplot as plt
# import matplotlib.image as mpimg

# 保存图像
# with open("output1.png", "wb") as f:
#     f.write(app.get_graph(xray=True).draw_mermaid_png())


def get_response(question: str):
    """
    For the given question will formulate a search query and use a custom GraphRAG retriever
    to fetch related content from the knowledge graph.

    Args:
        question (str): The question posed by the user for this graph RAG

    Returns:
        str: The results of the invoked graph based question
    """

    if question:
        inputs = {
            "question": question
        }
        output = app.invoke(inputs)

        answer = output["generation"]

        return answer

# Run
while True:
    content = input("user:")
    answer = get_response(content)
    print(answer)



