from transformers import BertModel,BertTokenizer

BERT_PATH = './bert-base-chinese'

tokenizer = BertTokenizer.from_pretrained(BERT_PATH)

print(tokenizer.tokenize('我很好，谢谢'))

bert = BertModel.from_pretrained(BERT_PATH)

print('load bert model over')

import torch
print(torch.cuda.is_available())

import torch
print(torch.__version__)  #注意是双下划线


