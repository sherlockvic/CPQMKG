# coding: UTF-8
import torch
import os
import torch.nn as nn
from transformers import AutoModel, AutoTokenizer, optimization
from transformers import BertTokenizer, BertModel, BertConfig,BertForSequenceClassification

import torch
cuda_available = torch.cuda.is_available()
print('cuda_available:', cuda_available)
print(torch.__version__)  #注意是双下划线

os.environ['CUDA_LAUNCH_BLOCKING'] = '1'

# model_path = "maml-bert/bert-base-chinese"
# # tokenizer_path = "C:/Users/86189/Desktop/SSS/maml-bert/bert-base-chinese"
# # tokenizer = BertTokenizer.from_pretrained(tokenizer_path)
# model = BertForSequenceClassification.from_pretrained(model_path)

class Config(object):

    """配置参数"""
    def __init__(self, dataset):
        #self.model_name = 'bert'
        self.model_dir= './bert-base-chinese'
        self.train_path = dataset + '/train.txt'                                # 训练集
        self.val_path = dataset + '/val.txt'                                    # 验证集
        self.test_path = dataset + '/test.txt'                                  # 测试集
        self.class_list = [x.strip() for x in open(
            dataset + '/class7.txt').readlines()]                                # 类别名单
        self.save_path = './saved_dict/' + dataset + '/' + self.model_dir + '.ckpt'        # 模型训练结果
        self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')   # 设备
        # model.to(self.device)  # 移动模型到cuda

        self.require_improvement = 1000                    # 若超过1000batch效果还没提升，则提前结束训练
        self.num_classes = len(self.class_list)                         # 类别数
        self.num_epochs = 5                                             # epoch数
        self.batch_size = 32                                   # mini-batch大小                                             # 每句话处理成的长度(短填长切)
        self.learning_rate = 5e-5                                       # 学习率

        self.bert_path = "./bert-base-chinese"
        #self.bert_path = 'bert-base-chinese'
        #self.config = BertConfig.from_json_file("bert-base-chinese/config.json")

        #self.tokenizer = BertTokenizer.from_pretrained('bert-base-chinese/')  ##注意此处为本地文件夹
        #self.model = BertModel.from_pretrained("bert-base-chinese/pytorch_model.bin", config=config)
        self.tokenizer = AutoTokenizer.from_pretrained(self.bert_path)

        self.hidden_size = 768


class Model(nn.Module):

    def __init__(self, config):
        super(Model, self).__init__()
        self.config = config
        self.bert = AutoModel.from_pretrained(config.bert_path)
        for param in self.bert.parameters():
            param.requires_grad = True
        # print('config num classes: ', config.num_classes)
        # exit()
        self.fc = nn.Linear(config.hidden_size, config.num_classes)

    def forward(self, x):
        batch = self.config.tokenizer(x, padding=True, max_length=256, truncation=True, return_tensors="pt")
        # 原来的：
        # _, pooled = self.bert(batch['input_ids'].to(self.config.device), attention_mask=batch['attention_mask'].to(self.config.device))
        # 改成了下面的：
        pooled = self.bert(batch['input_ids'].to(self.config.device), attention_mask=batch['attention_mask'].to(self.config.device))
        pooler_output = pooled.pooler_output
        # pooler_output = pooled.last_hidden_state
        out = self.fc(pooler_output)
        return out
