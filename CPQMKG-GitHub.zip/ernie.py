import paddle
from paddlenlp.transformers import ErnieTokenizer, ErnieModel
import paddle.nn as nn
import paddle.nn.functional as F

# 定义七分类任务的标签
labels = ["Category1", "Category2", "Category3", "Category4", "Category5", "Category6", "Category7"]

# 加载ERNIE模型和分词器
tokenizer = ErnieTokenizer.from_pretrained('ernie-1.0')
ernie_model = ErnieModel.from_pretrained('ernie-1.0')


class ErnieForClassification(nn.Layer):
    def __init__(self, num_classes=7):
        super(ErnieForClassification, self).__init__()
        self.ernie = ernie_model
        self.dropout = nn.Dropout(0.1)
        self.classifier = nn.Linear(self.ernie.config['hidden_size'], num_classes)

    def forward(self, input_ids, token_type_ids=None):
        # 使用ERNIE编码输入
        _, pooled_output = self.ernie(input_ids, token_type_ids)
        # 添加Dropout层
        dropout_output = self.dropout(pooled_output)
        # 进行分类
        logits = self.classifier(dropout_output)
        return logits


# 读取txt文件内容
def load_text_from_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read().strip()
    return text


# 文件路径
file_path = 'input_text.txt'
text = load_text_from_file(file_path)

# 将文本转化为ERNIE模型的输入
inputs = tokenizer(text, return_token_type_ids=True, return_attention_mask=False)
input_ids = paddle.to_tensor([inputs['input_ids']])
token_type_ids = paddle.to_tensor([inputs['token_type_ids']])

# 初始化模型
model = ErnieForClassification(num_classes=len(labels))

# 进行预测
model.eval()
with paddle.no_grad():
    logits = model(input_ids, token_type_ids)
    probs = F.softmax(logits, axis=-1)
    pred_label = labels[paddle.argmax(probs).numpy()[0]]

# 输出预测的类别
print(f"预测类别: {pred_label}")